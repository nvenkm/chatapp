function formatMessage(username, text) {
  return {
    username: username,
    text: text,
  };
}

module.exports = formatMessage;
